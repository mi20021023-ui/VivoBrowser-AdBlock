# vivo 浏览器去广告模块（libxposed API 102 实验版源码）

目标：vivo 浏览器 31.1.3.0；作用域仅 `com.vivo.browser`；LSPosed/libxposed API 102。

## 重要状态说明

这是根据用户提供 APK 的 DEX 方法表制作的**实验性源码工程**，不是已编译或已在手机验证的 APK。当前运行环境没有 Android SDK/Gradle/JADX，因此没有声称已构建成功。请先在 Android Studio 中 Sync/Build；若出现 API 签名差异，请以 libxposed API 102 实际依赖为准。

## 已从 APK DEX 验证的候选点

- `com.vivo.adsdk.ads.splash.SplashAD`：存在 `show(): void`、`loadAd(): void`、`loadAd(boolean): void`、`preLoadAd(): void`。
- `com.vivo.browser.download.utils.CpdRecommendUtils`：存在多个静态方法，返回 `java.util.List`，包括混淆方法 `a(...)`、`c(...)`、`d(...)`、`e(...)`、`f(...)`。
- 下载推荐模型 `DownloadRecommendItem` 和 `RecommendPayloads` 也确实存在，但本模块不直接改模型对象。

## 当前拦截策略

1. 对 `SplashAD` 中名为 `show`、`loadAd`、`preLoadAd` 且返回 `void` 的方法跳过原始实现，尝试阻止广告请求和展示。
2. 对 `CpdRecommendUtils` 中所有静态且返回 `List` 的方法返回空列表，尝试阻断下载推荐数据进入界面。
3. Hook 逐个异常隔离，并在 Logcat 中输出安装成功的候选方法。

## 构建

1. 在 Android Studio 打开此目录。
2. 使用 JDK 17，安装 Android SDK 35。
3. Gradle Sync（需要网络获取 Android Gradle Plugin 与 `io.github.libxposed:api:102.0.0`）。
4. Build > Build APK(s)。
5. 安装 APK，在 LSPosed 模块页启用，并确认作用域只勾选 vivo 浏览器 `com.vivo.browser`。
6. 重启浏览器进程，使用 `adb logcat -s VivoBrowserAdBlock` 检查实际 hook 数量。

## 回归测试

- 冷启动、热启动
- 首页浏览与搜索
- 普通文件下载、APK 下载、下载管理列表
- 网页视频播放

如果下载列表或网页功能异常，立即在 LSPosed 中禁用模块并强制停止浏览器。由于 `CpdRecommendUtils` 的方法名经过混淆，返回 List 的静态方法可能不全是广告数据；测试发现误伤时应改成仅 hook 经 smali/调用链确认的具体方法。

## 证据与限制

目标方法来自本次上传的 `浏览器_31.1.3.0.apk` 的 DEX class/method 表。类和方法签名已解析，但尚未反汇编方法体，也没有设备运行结果。因此该版本是“候选拦截”，不能保证开屏广告和下载推荐全部消失。不要将它当成稳定版。
