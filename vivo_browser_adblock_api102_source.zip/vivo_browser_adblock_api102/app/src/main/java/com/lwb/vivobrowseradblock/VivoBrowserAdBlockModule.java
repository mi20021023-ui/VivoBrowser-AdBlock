package com.lwb.vivobrowseradblock;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collections;
import java.util.List;
import android.util.Log;

import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedModuleInterface.PackageReadyParam;

/**
 * Experimental libxposed API 102 module for vivo Browser 31.1.3.0.
 * Hook targets were discovered in the supplied APK's DEX files.
 * This source is intentionally conservative and must be tested on-device.
 */
public final class VivoBrowserAdBlockModule extends XposedModule {
    private static final String TAG = "VivoBrowserAdBlock";
    private static final String TARGET_PACKAGE = "com.vivo.browser";

    @Override
    public void onPackageReady(PackageReadyParam param) {
        if (!TARGET_PACKAGE.equals(param.getPackageName()) || !param.isFirstPackage()) {
            return;
        }
        ClassLoader cl = param.getClassLoader();
        int splashHooks = hookSplash(cl);
        int recommendHooks = hookRecommendLists(cl);
        log(LogLevel.INFO, "Installed candidate hooks: splash=" + splashHooks
                + ", recommendation-list=" + recommendHooks);
    }

    private int hookSplash(ClassLoader cl) {
        int count = 0;
        try {
            Class<?> splash = cl.loadClass("com.vivo.adsdk.ads.splash.SplashAD");
            for (Method m : splash.getDeclaredMethods()) {
                String n = m.getName();
                // Block the ad SDK's explicit display and request entry points only.
                if (!("show".equals(n) || "loadAd".equals(n) || "preLoadAd".equals(n))) continue;
                if (m.getReturnType() != void.class) continue;
                try {
                    hook(m).intercept(chain -> null);
                    count++;
                    log(LogLevel.INFO, "Hooked splash entry: " + m.toGenericString());
                } catch (Throwable t) {
                    log(LogLevel.WARN, "Could not hook splash entry: " + m.toGenericString(), t);
                }
            }
        } catch (Throwable t) {
            log(LogLevel.WARN, "SplashAD class not available", t);
        }
        return count;
    }

    private int hookRecommendLists(ClassLoader cl) {
        int count = 0;
        try {
            Class<?> cpd = cl.loadClass("com.vivo.browser.download.utils.CpdRecommendUtils");
            for (Method m : cpd.getDeclaredMethods()) {
                if (!Modifier.isStatic(m.getModifiers())) continue;
                if (!List.class.isAssignableFrom(m.getReturnType())) continue;
                try {
                    hook(m).intercept(chain -> Collections.emptyList());
                    count++;
                    log(LogLevel.INFO, "Hooked CPD list factory: " + m.toGenericString());
                } catch (Throwable t) {
                    log(LogLevel.WARN, "Could not hook CPD list factory: " + m.toGenericString(), t);
                }
            }
        } catch (Throwable t) {
            log(LogLevel.WARN, "CpdRecommendUtils class not available", t);
        }
        return count;
    }

    private enum LogLevel { INFO, WARN }
    private void log(LogLevel level, String message) {
        if (level == LogLevel.INFO) Log.i(TAG, message); else Log.w(TAG, message);
    }
    private void log(LogLevel level, String message, Throwable t) {
        if (level == LogLevel.INFO) Log.i(TAG, message, t); else Log.w(TAG, message, t);
    }
}
