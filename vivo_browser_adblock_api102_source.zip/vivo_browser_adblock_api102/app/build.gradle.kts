plugins { id("com.android.application") }

android {
    namespace = "com.lwb.vivobrowseradblock"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.lwb.vivobrowseradblock"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}

dependencies {
    compileOnly("io.github.libxposed:api:102.0.0")
}
